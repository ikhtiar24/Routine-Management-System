<head>
		<title>Responsive Website</title>
		<meta name = "viewport" content="width=device-width, initial-scale=1.0"/>
		<link href="Style/Css/style.css" rel="stylesheet" type="text/css">
	</head>

	<body> 
        <header class="mainHeader">
            <ul>
                <li><a href="1.%20Home.php">Home</a></li>
                <li><a href="2.%20View-Routine.php">View-Routine</a>
                   
                    <ul>
                        <li> <a href="3.%20Full%20Routine.php">Full Routine</a></li><br>
                        <li> <a href="5.%20Go%20Course%20Routine.php">Course Routine</a></li><br>
                        <li> <a href="7.%20Go%20Section%20Routine.php">Section Routine</a></li><br>
                        <li> <a href="9.%20Go%20Teacher%20Initial%20Routine.php">Teacher Initial Routine</a></li>
                    </ul>  
                </li>
                <li><a href="10.%20Log%20in.php">Login</a></li>
               
                <form>
                    <input type="text" name="Searchbox" class="Search" placeholder="Search...">
                </form>
            </ul>
        </header>