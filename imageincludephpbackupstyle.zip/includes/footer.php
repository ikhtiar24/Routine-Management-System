  <?php
    echo "<p>All rights reserved &copy;Copyright</p>";
   ?>