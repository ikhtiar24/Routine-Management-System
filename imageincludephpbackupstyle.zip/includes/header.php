
	<head>
        <title>Responsive Website</title>
		<meta name = "viewport" content="width=device-width, initial-scale=1.0"/>
		<link href="Style/Css/style.css" rel="stylesheet" type="text/css">
	</head>

    
    
	<body> 
       <header class="mainHeader">
            <ul>
                <li><a href="1. Home.php ">Home</a></li>
                <li><a href="2. View-Routine.php">View-Routine</a> </li>
                <li><a href="10. Log in.php">Login</a></li>
               
               <form>
                  <input type="text" name="Searchbox" class="Search" placeholder="Search...">
               </form>
            </ul>
        </header>
         
       
        <header class="mainHeader1">
                <p> Semi Automated Time Scheduling Management System for University Classes</p>
        </header> 
        
   
        
        